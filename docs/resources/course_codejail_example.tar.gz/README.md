Example edX Course
==================

This is the source code for an example edX course demonstrating the various capabilities of the MITx Grading Library. You can view this course to see live examples in action [here](https://edge.edx.org/courses/course-v1:MITx+grading-library+examples/) (hosted on edX edge).
