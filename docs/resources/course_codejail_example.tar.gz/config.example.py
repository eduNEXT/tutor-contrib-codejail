"""
config.py

Sets username and password for edX login

Note that config.py should be in the .gitignore file
"""
username = "email@address.com"
password = "edx password"
